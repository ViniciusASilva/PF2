<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>Pesquisar Veículo</title>
  </head>
  <body>
	<?php
		include "conexao.php";
		$database = $factory->createDatabase();
		$veiculos = $database->getReference('VC01')->getSnapshot();
		$todosStatus = $database->getReference('VC21')->getSnapshot();
    ?> 
  
  
    <div class="container">
	  <div class="row">
	    <div class="col">
		  <h1>Pesquisar veículo</h1>
		  <nav class="navbar navbar">
		    <form class="form-inline" action="pesquisaCarro.php" method="POST">
		      <input id="busca" class="form-control mr-sm-2" type="search" aria-label="Search" name="busca" autofocus>
		    </form>
		  </nav>
		
		  <table class="table table-hover">
		    <thead>
			  <tr>
			    <th scope="col">Modelo</th>
			    <th scope="col">Marca</th>
			    <th scope="col">KM</th>
				<th scope="col">ANO</th>
			    <th scope="col">Vaga</th>
				<th scope="col">Placa</th>
				<th scope="col">Valor venda</th>
				<th scope="col">Valor compra</th>
				<th scope="col">Comissão</th>
				<th scope="col">Funcoes</th>
			  </tr>
		    </thead>
		    <tbody id="tbodyLista">
			
			 
			  <input id="listaCar" type="hidden"  value='<?=json_encode($veiculos->getValue()); ?>'>
			  
			<?php
			    
				foreach ($veiculos->getValue() as $veiculo) : 
				  if(isset($veiculo['VC01_PC_COMISS']))
					  $VC01_PC_COMISS = $veiculo['VC01_PC_COMISS'];
				  else 
					  $VC01_PC_COMISS = 0;
				  
				  $PC_COMISS = $veiculo['VC01_VL_VENDA'] - $veiculo['VC01_VL_COMPRA'];
																 
				  $PC_COMIIS = ($PC_COMISS * $VC01_PC_COMISS) / 100;
				
				  $cod_carro = $veiculo['VC01_CD_CAR'];
				endforeach
				 
			?>  
		    </tbody>
		  </table>
		
		  <a href="index.php" class="btn btn-info">Voltar para o inicio</a>
	    </div>
	  </div>
    </div>
	
	<!-- Modal -->
	<div class="modal fade" id="confirma" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog" role="document">
		<div class="modal-content">
		  <div class="modal-header">
			<h5 class="modal-title" id="exampleModalLabel">Confirmação de exclusão</h5>
			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			  <span aria-hidden="true">&times;</span>
			</button>
		  </div>
		  <div class="modal-body">
		  <form action="excluindo.php" method="POST">
			<p>Deseja realmente excluir <b id="nome_carro"> Nome do carro</b> ?</p>
		  </div>
		  <div class="modal-footer">
			  <button type="button" class="btn btn-secondary" data-dismiss="modal">Não</button>
			  <input type="hidden" name="nome" id="nome_carro_1" value="">
			  <input type="hidden" name="id" id="cod_carro" value="">
			  <input type="submit" class="btn btn-danger" value="Excluir">
			</form>
		  </div>
		</div>
	  </div>
	</div>
	
	<script type="text/javascript">
	  function pegar_dados(id, nome) {
		  document.getElementById('nome_carro').innerHTML = nome;
		  document.getElementById('nome_carro_1').value = nome;
		  document.getElementById('cod_carro').value = id;
	  }
	</script>

	
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  	<script type="text/javascript">
	     $(document).ready(function() {
			let lista = JSON.parse($("#listaCar").val());

			
			let html = '';
			
			for(let i = 0; i < lista.length; i++){
				if(lista[i] != null){
					console.log(lista[i]);
				    html += "<tr>"
					html += "<th scope='row'>" + lista[i].VC01_NM_MODELO + "</th>"
					html += "<td>" + lista[i].VC01_CD_MARCA + "</td>"
					html += "<td>" + lista[i].VC01_NR_KM + "</td>"
					html += "<td>" + lista[i].VC01_DT_ANO + "</td>"
					html += "<td>" + lista[i].VC01_NR_VAGA + "</td>"
					html += "<td>" + lista[i].VC01_DS_PLACA + "</td>"
					html += "<td>" + lista[i].VC01_VL_VENDA + "</td>"
					html += "<td>" + lista[i].VC01_VL_COMPRA + "</td>"
					html += "<td>" + ((lista[i].VC01_VL_VENDA - lista[i].VC01_VL_COMPRA ) * (lista[i].VC01_PC_COMISS == undefined ? 0 : lista[i].VC01_PC_COMISS ) / 100) + "</td>"
					html += "<td><a href='editaCarro.php?id='" + lista[i].VC01_CD_CAR + "' class='btn btn-sucess'>Editar</a></td>"
					html += "</tr>"
				}
					

			}
			$("#tbodyLista").html(html)
			
			$("#busca").keyup(function(){
			
			let busca = $("#busca").val().toUpperCase()
			let html = ""
			console.log(busca);
			for(let i = 0; i < lista.length; i++){
				if(lista[i] != null){
					if((lista[i].VC01_CD_MARCA.toUpperCase().indexOf(busca) > -1) || (lista[i].VC01_NM_MODELO.toUpperCase().indexOf(busca) > -1) || 
					   (lista[i].VC01_NR_KM.toUpperCase().indexOf(busca) > -1) || (lista[i].VC01_DT_ANO.toUpperCase().indexOf(busca) > -1)){

						html += "<tr>"
						html += "<th scope='row'>" + lista[i].VC01_NM_MODELO + "</th>"
						html += "<td>" + lista[i].VC01_CD_MARCA + "</td>"
						html += "<td>" + lista[i].VC01_NR_KM + "</td>"
						html += "<td>" + lista[i].VC01_DT_ANO + "</td>"
						html += "<td>" + lista[i].VC01_NR_VAGA + "</td>"
						html += "<td>" + lista[i].VC01_DS_PLACA + "</td>"
						html += "<td>" + lista[i].VC01_VL_VENDA + "</td>"
						html += "<td>" + lista[i].VC01_VL_COMPRA + "</td>"
						html += "<td>" + ((lista[i].VC01_VL_VENDA - lista[i].VC01_VL_COMPRA ) * (lista[i].VC01_PC_COMISS == undefined ? 0 : lista[i].VC01_PC_COMISS ) / 100) + "</td>"
						html += "<td><a href='editaCarro.php?id=" + lista[i].VC01_CD_CAR + "' class='btn btn-sucess'>Editar</a></td>"
						html += "</tr>"
					}
				}
			}
			$("#tbodyLista").html(html)

})

		});
	</script>
  </body>
</html>
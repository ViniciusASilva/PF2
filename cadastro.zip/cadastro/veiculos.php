<?php 

	include "conexao.php";
	$prop = $_REQUEST['prop'];
	$database = $factory->createDatabase();
	$veics = $database->getReference('VC01')->getSnapshot();
	$avaliacoes = $database->getReference('VC05')->getSnapshot();
	$existe = 0;
	foreach($veics->getValue() as $veic) :
		if($veic['VC01_CD_PROP'] == $prop){
			foreach($avaliacoes->getValue() as $avaliacao):
			  if ($avaliacao['VC05_CD_CAR'] == $veic['VC01_CD_CAR']){
				  $existe = 1;
			  }
			endforeach;
			
			if($existe == 0) {
				$veiculos[] = array(
				  'VC01_CD_CAR' => $veic['VC01_CD_CAR'],
				  'VC01_NM_CAR' => utf8_encode($veic['VC01_NM_CAR']),
				);
			}
		}
		$existe = 0;
	endforeach;
  
  echo (json_encode($veiculos));
  
?>
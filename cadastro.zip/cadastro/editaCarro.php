<?php
	require __DIR__.'/vendor/autoload.php';
    use Kreait\Firebase\Factory;
	include "conexao.php";
    $database = $factory->createDatabase();
	$idCar = $_GET['id'] ?? '';
	$idVeic = $idCar;
	$idVeic--;
	$veiculos = $database->getReference('VC01')->getSnapshot();
	$proprietarios = $database->getReference('VC02')->getSnapshot();
	
    $msg = '';
    if(isset($_POST['id'])) {
      $novoCarro = [
        'VC01_CD_CAR' => $idCar,
        'VC01_CD_PROP' => $_POST['VC01_CD_PROP'],
        'VC01_NM_MODELO' => $_POST['VC01_NM_MODELO'],
		'VC01_NM_CAR' => $_POST['VC01_NM_MODELO']." - ".$_POST['VC01_CD_MARCA']." - ". $_POST['VC01_DS_PLACA'],
        'VC01_CD_MARCA' => $_POST['VC01_CD_MARCA'],
        'VC01_DT_ANO' => $_POST['VC01_DT_ANO'],
        'VC01_CD_COR' => $_POST['VC01_CD_COR'],
        'VC01_ID_UNIDON' => $_POST['VC01_ID_UNIDON'],
        'VC01_ID_BATIDO' => $_POST['VC01_ID_BATIDO'],
        'VC01_QT_BATIDS' => $_POST['VC01_QT_BATIDS'],
        'VC01_DS_PLACA' => $_POST['VC01_DS_PLACA'],
        'VC01_QT_PASS' => $_POST['VC01_QT_PASS'],
        'VC01_VL_COMPRA' => $_POST['VC01_VL_COMPRA'],
		'VC01_VL_VENDA' => $_POST['VC01_VL_VENDA'],
		'VC01_PC_COMISS' => $_POST['VC01_PC_COMISS'],
        'VC01_NR_KM' => $_POST['VC01_NR_KM'],
		'VC01_NR_VAGA' => $_POST['VC01_NR_VAGA'],
        'VC01_DS_IMG' => $_POST['VC01_DS_IMG']
      ];
      $database -> getReference('VC01/' . $idVeic)->set($novoCarro);
      $msg = "Carro alterado com sucesso!";
	  header("location: editaCarro.php?id=$idCar");
    }
	
	
	
?>

<!doctype html>
<html lang="en">
  <head>
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js" type="text/javascript"></script>
    
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>    

    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>

  <title>Alteração de veiculo</title>
	<link href="css/cadastroCarro.css" rel="stylesheet">
  </head>
  <body>
  
      <p>
        <strong>
          <?php 
            echo $msg;
          ?>
        <strong>
      </p>
  
  <?php 
	  foreach($veiculos->getValue() as $veiculo):
		if($veiculo['VC01_CD_CAR'] == $idCar){
  ?>
  <div class="container">
    <div class="form-signin"> 
      <h2>Alteração de veículo</h2>

      <form name="signup" method="post" class="form-signin">
      <div class="row">
      <!--ID-->
        <div class="form-group col-md-2">
            <input class="form-control" type="hidden" name="id" id="id" placeholder="ID" value="<?php echo $idCar ?>">
        </div>
      </div>  
      <div class="row">
         <!--Proprietário-->
        <div class="form-group col-md-10">
          <label for="name">Proprietário</label>
			<select name="VC01_CD_PROP" id="VC01_CD_PROP" class='form-control'>
			<?php 
			    foreach($proprietarios->getValue() as $proprietario) :
					if($proprietario['VC02_ID_PROP'] == $veiculo['VC01_CD_PROP']){
						echo "<option class='"."form-control"." '. value='".$proprietario["VC02_ID_PROP"]."'>".$proprietario["VC02_NM_PROP"]." - ".$proprietario["VC02_NR_CPFCNPJ"]."</option>";
					}
				endforeach;
			?> 
			</select> 
        </div>
        <!--Modelo-->
        <div class="form-group col-md-5">
          <label for="campo2">Modelo</label>
          <input class="form-control" type="text" name="VC01_NM_MODELO" id="VC01_NM_MODELO" placeholder="Modelo" value="<?php echo $veiculo['VC01_NM_MODELO'] ?>">
        </div>
       <!--Marca-->
        <div class="form-group col-md-5">
          <label for="campo2">Marca</label>
          <input class="form-control" type="text" name="VC01_CD_MARCA" id="VC01_CD_MARCA" placeholder="Marca" value="<?php echo $veiculo['VC01_CD_MARCA'] ?>">
        </div>
      </div>

      <div class="row">
        <!--Ano-->
        <div class="form-group col-md-5">
          <label for="campo2">Ano</label>
          <input class="date-own form-control" type="text" name="VC01_DT_ANO" id="VC01_DT_ANO" placeholder="Ano" value="<?php echo $veiculo['VC01_DT_ANO'] ?>">
        </div>
        <!--Cor-->
        <div class="form-group col-md-5">
          <label for="campo2">Cor</label>
          <input class="form-control" type="text" name="VC01_CD_COR" id="VC01_CD_COR" placeholder="Cor" value="<?php echo $veiculo['VC01_CD_COR'] ?>">
        </div>
        <!--Placa-->
        <div class="form-group col-md-5">
          <label for="campo2">Placa</label>
          <input class="form-control" type="text" name="VC01_DS_PLACA" id="VC01_DS_PLACA" placeholder="Placa" value="<?php echo $veiculo['VC01_DS_PLACA'] ?>">
        </div>
        <!--Passageiros-->
        <div class="form-group col-md-5">
          <label for="campo2">Passageiros</label>
          <input class="form-control" type="text" name="VC01_QT_PASS" id="VC01_QT_PASS" placeholder="Passageiros" value="<?php echo $veiculo['VC01_QT_PASS'] ?>">
        </div>
      </div>
      
      <div class="row">
        <!--Valor da Compra-->
        <div class="form-group col-md-5">
          <label for="campo2">Valor da Compra</label>
          <input class="form-control" type="text" name="VC01_VL_COMPRA" id="VC01_VL_COMPRA" placeholder="Valor da Compra" value="<?php echo $veiculo['VC01_VL_COMPRA'] ?>">
        </div>
		<!--Valor da Venda-->
        <div class="form-group col-md-5">
          <label for="campo2">Valor de Venda</label>
          <input class="form-control" type="text" name="VC01_VL_VENDA" id="VC01_VL_VENDA" placeholder="Valor de venda" value="<?php echo $veiculo['VC01_VL_VENDA'] ?>">
        </div>
		<!--Valor da Venda-->
        <div class="form-group col-md-5">
          <label for="campo2">Comissão</label>
          <input class="form-control" type="text" name="VC01_PC_COMISS" id="VC01_PC_COMISS" placeholder="% de comissão" value="<?php echo $veiculo['VC01_PC_COMISS'] ?>">
        </div>
        <!--Kilometros Rodados-->
        <div class="form-group col-md-5">
          <label for="campo2">Kilometros Rodados</label>
          <input class="form-control" type="text" name="VC01_NR_KM" id="VC01_NR_KM" placeholder="Kilometros Rodados" value="<?php echo $veiculo['VC01_NR_KM'] ?>">
        </div>
		<!--Unico dono-->
        <div class="form-group col-md-5">
          <label for="campo2">Unico dono</label>
          <input class="form-control" type="text" name="VC01_ID_UNIDON" id="VC01_ID_UNIDON" placeholder="Unico dono" value="<?php echo $veiculo['VC01_ID_UNIDON'] ?>">
        </div>
		<!--Batidas-->
        <div class="form-group col-md-5">
          <label for="campo2">Batidas</label>
          <input class="form-control" type="text" name="VC01_ID_BATIDO" id="VC01_ID_BATIDO" placeholder="Já foi batido" value="<?php echo $veiculo['VC01_ID_BATIDO'] ?>">
        </div>
		<!--Qtde. Batidas-->
        <div class="form-group col-md-5">
          <label for="campo2">Qt. Batidas</label>
          <input class="form-control" type="text" name="VC01_QT_BATIDS" id="VC01_QT_BATIDS" placeholder="Quantidade de batidas" value="<?php echo $veiculo['VC01_QT_BATIDS'] ?>">
        </div>
		<!--NR. Vaga-->
        <div class="form-group col-md-5">
			<label for="campo2">Nr. Vaga</label>
            <input class="form-control" type="text" name="VC01_NR_VAGA" id="VC01_NR_VAGA" placeholder="Nr. Vaga" value="<?php echo $veiculo['VC01_NR_VAGA'] ?>">
        </div>
        <!--Imagem-->
        <div class="form-group col-md-5">
          <label for="campo2">Imagem do Carro</label>
          <input type="file" value="Escolher  " name="VC01_DS_IMG" id="VC01_DS_IMG" value="<?php echo $veiculo['VC01_DS_IMG'] ?>">
        </div>
      </div>

      
      <!--ID-->
      <!-- <div class="form-group row">
          <div class="col-10">
            <input class="form-control" type="number" name="id" id="id" placeholder="ID">
          </div>
        </div> -->
          
          <input type="submit" name="btnCadAutomovel" class="btn btn-primary" value="Cadastrar"\>
          <a href="index.php" class="btn btn-default">Voltar</a>
      </form>
    </div>  
	</div>
  <?php
	}
  endforeach
  
  ?>
  <script>
    $('.date-own').datepicker({
    format: "yyyy",
    viewMode: "years", 
    minViewMode: "years"
    });
    $(document).ready(function() {
    $("#amount").on("input", function() {
        // allow numbers, a comma or a dot
        var v= $(this).val(), vc = v.replace(/[^0-9,\.]/, '');
        if (v !== vc)        
            $(this).val(vc);
    });
    $("#distance").on("input", function() {
        // allow numbers, a comma or a dot
        var v= $(this).val(), vc = v.replace(/[^0-9,\.]/, '');
        if (v !== vc)        
            $(this).val(vc);
    });
});

  </script>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>	
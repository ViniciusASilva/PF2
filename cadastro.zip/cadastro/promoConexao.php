<?php
require __DIR__.'/vendor/autoload.php';
use Kreait\Firebase\Factory;
$factory = (new Factory)->withServiceAccount(__DIR__.'/projeto-final-e1184-firebase-adminsdk-h7pfw-15c9f662be.json');
$database = $factory->createDatabase();
$promocao = $database->getReference('VC01')->getSnapshot();
?>


<?php 

	include "conexao.php";
	$setor = $_REQUEST['setor'];
	$database = $factory->createDatabase();
	$veics = $database->getReference('VC01')->getSnapshot();
	foreach($veics->getValue() as $veic) :
		if($veic['VC01_CD_PROP'] == $setor){
			$funcionarios[] = array(
			  'VC01_CD_CAR' => $veic['VC01_CD_CAR'],
			  'VC01_NM_CAR' => utf8_encode($veic['VC01_NM_CAR']),
			);
		}
	endforeach;
  
  echo (json_encode($funcionarios));
  
?>
<?php 

	include "conexao.php";
	$setor = $_REQUEST['setor'];
	$database = $factory->createDatabase();
	$funcs = $database->getReference('VC20')->getSnapshot();
	foreach($funcs->getValue() as $funcionario) :
		if($funcionario['VC20_ID_SETOR'] == $setor){
			$funcionarios[] = array(
			  'VC20_ID_FUNC' => $funcionario['VC20_ID_FUNC'],
			  'VC20_NM_FUNC' => utf8_encode($funcionario['VC20_NM_FUNC']),
			);
		}
	endforeach;
  
  echo (json_encode($funcionarios));
  
?>
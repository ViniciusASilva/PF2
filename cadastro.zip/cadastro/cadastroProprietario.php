<?php
    include "conexao.php";
    $database = $factory->createDatabase();
    $msg = '';
    if(isset($_POST['id'])) {
		
	  $cpf_enviado = validaCPF($_POST['VC02_NR_CPFCNPJ']);
	  if ($cpf_enviado == true) {
        $novoProp = [
          'VC02_DS_EMAIL' => $_POST['VC02_DS_EMAIL'],
          'VC02_ID_PROP' => $_POST['id'],
		  'VC02_ID_SEXO' => $_POST['VC02_ID_SEXO'],
          'VC02_NM_PROP' => $_POST['VC02_NM_PROP'],
		  'VC02_NR_CPFCNPJ' => $_POST['VC02_NR_CPFCNPJ'],
		  'VC02_NR_DDDCEL' => $_POST['VC02_NR_DDDCEL'],
		  'VC02_NR_CEL' => $_POST['VC02_NR_CEL'],
		  'VC02_NR_DDDTEL' => $_POST['VC02_NR_DDDTEL'],
		  'VC02_NR_TEL' => $_POST['VC02_NR_TEL'],
		  'VC02_NR_IDADE' => $_POST['VC02_NR_IDADE']
        ];
	  
        $database -> getReference('VC02/' . $_POST['id'])->set($novoProp);
        $msg = "Proprietário cadastrado com sucesso!";
	    header("location: index.php");
	  }
	  else {
		$msg = "CPF Inválido!"; 
		echo $msg;
	  }
		
      
    }
	$sexos = $database->getReference('VC30')->getSnapshot();
	$proprietarios = $database->getReference('VC02')->getSnapshot();
	
	foreach($proprietarios->getValue() as $proprietario) :
	    $i = 1;
		if ($proprietario['VC02_ID_PROP'] == $i) {
			$id_prop_max = $proprietario['VC02_ID_PROP'];
		}
		$i ++;
	endforeach;
	
	
	
	function validaCPF($cpf) {
 
		// Extrai somente os números
		$cpf = preg_replace( '/[^0-9]/is', '', $cpf );
		 
		// Verifica se foi informado todos os digitos corretamente
		if (strlen($cpf) != 11) {
			return false;
		}

		// Verifica se foi informada uma sequência de digitos repetidos. Ex: 111.111.111-11
		if (preg_match('/(\d)\1{10}/', $cpf)) {
			return false;
		}

		// Faz o calculo para validar o CPF
		for ($t = 9; $t < 11; $t++) {
			for ($d = 0, $c = 0; $c < $t; $c++) {
				$d += $cpf[$c] * (($t + 1) - $c);
			}
			$d = ((10 * $d) % 11) % 10;
			if ($cpf[$c] != $d) {
				return false;
			}
		}
		return true;

	}
	
?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js" type="text/javascript"></script>
    
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>    

    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>


    <title>Cadastro de Proprietário</title>
    <link href="css/cadastroProp.css" rel="stylesheet">
  </head>
  <body>
  <div class="container">
    <div class="form-signin"> 
      <h2>Cadastrar Proprietário</h2>
      <p>
        <strong>
          <?php 
            echo $msg;
          ?>
        <strong>
      </p>
      <form name="signup" method="post" class="form-signin">
      <!-- <div class="row"> -->
      <!--ID-->
        <div class="form-group col-md-2">
            <input class="form-control" type="hidden" name="id" id="id" placeholder="ID" value="<?php echo $id_prop_max ?>">
        </div>
      </div>
      <div class="row">
	    <div class="form-group col-md-3">
          <label for="name">CPF</label>
          <input class="form-control" type="text" name="VC02_NR_CPFCNPJ" id="VC02_NR_CPFCNPJ" placeholder="CPF" pattern="/^-?\d+\.?\d*$/" size="11" maxLength="11" required="required">
        </div>
         <!--Proprietário-->
        <div class="form-group col-md-10">
          <label for="name">Nome do proprietario</label>
          <input class="form-control" type="text" name="VC02_NM_PROP" id="VC02_NM_PROP" placeholder="Nome do proprietario" required="required">
        </div>
		<div class="form-group col-md-3">
          <label for="name">Idade</label>
          <input class="form-control" type="text" name="VC02_NR_IDADE" id="VC02_NR_IDADE" placeholder="Idade" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==3) return false;" required="required">
        </div>
		<div class="form-group col-md-3">
          <label for="name">Sexo</label>
		  <select name="VC02_ID_SEXO" id="VC02_ID_SEXO" class='form-control' required="required">
		  <option value="">Selecione o sexo</option>
		  <?php 
		    foreach($sexos->getValue() as $sexo) :
				echo "<option class='"."form-control"." '. value='".$sexo['VC30_ID_SEX']."'>".$sexo['VC30_ID_SEX']." - ".$sexo['VC30_DS_SEX']."</option>";
			endforeach;
		  ?> 
		  </select> 
        </div>
		<div class="form-group col-md-5">
          <label for="name">E-mail</label>
          <input class="form-control" type="email" name="VC02_DS_EMAIL" id="VC02_DS_EMAIL" placeholder="E-mail" required="required">
        </div>
		<div class="form-group col-md-1">
          <label for="name">DDD</label>
          <input class="form-control" type="text" name="VC02_NR_DDDTEL" id="VC02_NR_DDDTEL" placeholder="DDD" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==2) return false;" required="required">
        </div>
		<div class="form-group col-md-3">
          <label for="name">Telefone</label>
          <input class="form-control" type="text" name="VC02_NR_TEL" id="VC02_NR_TEL" placeholder="Telefone" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==8) return false;" required="required">
        </div>
		<div class="form-group col-md-1">
          <label for="name">DDD</label>
          <input class="form-control" type="text" name="VC02_NR_DDDCEL" id="VC02_NR_DDDCEL" placeholder="DDD" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==2) return false;" required="required">
        </div>
		<div class="form-group col-md-3">
          <label for="name">Celular</label>
          <input class="form-control" type="text" name="VC02_NR_CEL" id="VC02_NR_CEL" placeholder="Celular" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==9) return false;" required="required">
        </div>
      </div>
		  <button type="submit" name="btnCadAutomovel" class="btn btn-primary" target="_blank" href='index.php'>Cadastrar</button>
          <a href="index.php" class="btn btn-default">Voltar</a>
      </form>
    </div>  
	</div>
  
  <script>
    
    $('.date-own').datepicker({
    format: "yyyy",
    viewMode: "years", 
    minViewMode: "years"
    });

    $(document).ready(function() {
    $("#valorCompra").on("input", function() {
        // allow numbers, a comma or a dot
        var v= $(this).val(), vc = v.replace(/[^0-9,\.]/, '');
        if (v !== vc)        
            $(this).val(vc);
    });
    
    $("#kmRodado").on("input", function() {
        // allow numbers, a comma or a dot
        var v= $(this).val(), vc = v.replace(/[^0-9,\.]/, '');
        if (v !== vc)        
            $(this).val(vc);
    });
});

  </script>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>	
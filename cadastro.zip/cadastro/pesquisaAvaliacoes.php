<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>Pesquisar avaliações</title>
  </head>
  <body>
  
   <?php
     include "conexao.php";
     $database = $factory->createDatabase();
	 $veiculos = $database->getReference('VC01')->getSnapshot();
	 $proprietarios = $database->getReference('VC02')->getSnapshot();
     $avaliacoes = $database->getReference('VC05')->getSnapshot();
	 $statusAvaliacao = $database->getReference('VC06')->getSnapshot();
	 $funcionarios = $database->getReference('VC20')->getSnapshot();
   ?> 
  
  
    <div class="container">
	  <div class="row">
	    <div class="col">
		  <h1>Pesquisar</h1>
		  <nav class="navbar navbar-light bg-light">
		    <form class="form-inline" action="pesquisaCarro.php" method="POST">
		      <input class="form-control mr-sm-2" type="search" placeholder="Modelo" aria-label="Search" name="busca" autofocus>
			  <button class="btn btn-outline-sucess my-2 my-sm-0" type="submit">Pesquisar</button>
		    </form>
		  </nav>
		
		  <table class="table table-hover">
		    <thead>
			  <tr>
			    <th scope="col">Numero</th>
			    <th scope="col">Veiculo</th>
				<th scope="col">Proprietário</th>
				<th scope="col">Mecanico</th>
			    <th scope="col">Status</th>
				<th scope="col">Funcoes</th>
			  </tr>
		    </thead>
		    <tbody>
			  
			 
			<?php
			  foreach ($avaliacoes->getValue() as $avaliacao) : 
				if($avaliacao['VC05_ID_STATUS'] == 1) {
			?>
			<tr>
			    <?php $cod_aval = $avaliacao['VC05_ID_AVAL']; ?>
				<th scope='row'><?php echo $avaliacao['VC05_ID_AVAL'] ?></th>
				<?php
				    $idCar = 2;
					foreach($veiculos->getValue() as $veiculo) :
						if($veiculo['VC01_CD_CAR'] == $avaliacao['VC05_CD_CAR']) {
							$idCar = 1;
							echo "<td>'".$veiculo['VC01_NM_CAR']."'</td>";
						}
					endforeach;
					if ($idCar == 2){
						echo "<td> </td>";
					}
				?>
				<?php
				    $idProp = 2;
					foreach($proprietarios->getValue() as $proprietario) :
						if($proprietario['VC02_ID_PROP'] == $avaliacao['VC05_CD_PROP']) {
							$idProp = 1;
							echo "<td>'".$proprietario['VC02_NM_PROP']."'</td>";
						}
					endforeach;
					if ($idProp == 2){
						echo "<td> </td>";
					}
				?>
				<?php
					$idFunc = 2;
					foreach($funcionarios->getValue() as $funcionario) :
						if($funcionario['VC20_ID_FUNC'] == $avaliacao['VC05_CD_FUNC']) {
							$idFunc = 1;
							echo "<td>'".$funcionario['VC20_NM_FUNC']."'</td>";
						}
					endforeach;
					if ($idFunc == 2){
						echo "<td> </td>";
					}
				?>
				<?php 
					$idStatus = 2;
					foreach($statusAvaliacao->getValue() as $status) :
						if ($status['VC06_ID_STATUS'] == $avaliacao['VC05_ID_STATUS']) {
							$idStatus = 1;
							echo "<td>'".$status['VC06_DS_STATUS']."'</td>";
						}
					endforeach;
					if ($idStatus == 2){
						echo "<td> </td>";
					}
				?>
				<?php
				  echo "<td width=150px> 
				          <a href='editaAvaliacoes.php?id=$cod_aval' class='btn btn-sucess'>Selecionar</a> 
						  <a href='finalizaAvaliacoes.php?id=$cod_aval' class='btn btn-danger'>Finalizar</a> 
						</td>"
				?>
			</tr>
				   
				  
			<?php
				}
				endforeach;
			?>  
			  
		    </tbody>
		  </table>
		
		  <a href="index.php" class="btn btn-info">Voltar para o inicio</a>
	    </div>
	  </div>
    </div>
	
	<!-- Modal -->
	<div class="modal fade" id="confirma" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog" role="document">
		<div class="modal-content">
		  <div class="modal-header">
			<h5 class="modal-title" id="exampleModalLabel">Confirmação de exclusão</h5>
			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			  <span aria-hidden="true">&times;</span>
			</button>
		  </div>
		  <div class="modal-body">
		  <form action="excluindo.php" method="POST">
			<p>Deseja realmente excluir <b id="nome_carro"> Nome do carro</b> ?</p>
		  </div>
		  <div class="modal-footer">
			  <button type="button" class="btn btn-secondary" data-dismiss="modal">Não</button>
			  <input type="hidden" name="nome" id="nome_carro_1" value="">
			  <input type="hidden" name="id" id="cod_carro" value="">
			  <input type="submit" class="btn btn-danger" value="Excluir">
			</form>
		  </div>
		</div>
	  </div>
	</div>
	
	<script type="text/javascript">
	  function pegar_dados(id, nome) {
		  document.getElementById('nome_carro').innerHTML = nome;
		  document.getElementById('nome_carro_1').value = nome;
		  document.getElementById('cod_carro').value = id;
		  window.alert(nome);
	  }
	</script>
	
	
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>
<?php
    require __DIR__.'/vendor/autoload.php';
    use Kreait\Firebase\Factory;
    $msg = '';
    if(isset($_POST['id'])) {
      $factory =  (new Factory()) -> withDatabaseUri('https://projeto-final-e1184.firebaseio.com/');
      $database = $factory->createDatabase();
      $novoCarro = [
        'id' => $_POST['id'],
        'proprietario' => $_POST['proprietario'],
        'modelo' => $_POST['modelo'],
        'marca' => $_POST['marca'],
        'ano' => $_POST['ano'],
        'cor' => $_POST['cor'],
        'placa' => $_POST['placa'],
        'passageiros' => $_POST['passageiros'],
        'amount' => $_POST['valorCompra'],
        'distance' => $_POST['kmRodado'],
        'imagem' => $_POST['imagem']
      ];
      $database -> getReference('cadastroCarro/' . $_POST['id'])->set($novoCarro);
      $msg = "Carro cadastrado com sucesso!";
    }
?>


<?php
    require __DIR__.'/vendor/autoload.php';
    use Kreait\Firebase\Factory;
	include "conexao.php";
    $database = $factory->createDatabase();
    $msg = '';
    if(isset($_POST['id'])) {
	  if(!EMPTY($_POST['VC05_CD_FUNC']) && !EMPTY($_POST['VC05_CD_CAR']) && !EMPTY($_POST['VC05_CD_PROP'])) {
		  $idAval = $_POST['id'];
		  $idAval++;
		  $novaAval = [
			'VC05_ID_AVAL' => $idAval,
			'VC05_CD_FUNC' => $_POST['VC05_CD_FUNC'],
			'VC05_CD_CAR' => $_POST['VC05_CD_CAR'],
			'VC05_CD_PROP' => $_POST['VC05_CD_PROP'],
			'VC05_ID_STATUS' => 1
		  ];
		  $database -> getReference('VC05/' . $_POST['id'])->set($novaAval);
		  $msg = "Avaliação cadastrada com sucesso!";
		  
		  $idMecanico = $_POST['VC05_CD_FUNC'];
		  $idMecanico --;
			  
		  $atualizaStatusMecanico = [
			'VC23_ID_FUNC' => $_POST['VC05_CD_FUNC'],
			'VC23_ID_STATUS' => 2,
			'VC23_DT_ATUSIS' => date('Ymd h:i:s') 
		  ];
		  $database -> getReference('VC23/' . $idMecanico)->set($atualizaStatusMecanico);
		  
		  
		  $itemAval = [
			'VC07_ID_AVAL' => $idAval,
			'VC07_DS_LANC' => '',
			'VC07_VL_TOTAL' => ''
		  ];
		  $database -> getReference('VC07/' . $_POST['id'])->set($itemAval);
	  }
	  else
	    $msg = "Erro ao cadastrar avaliação. Selecione todos os itens!";
    }
	
	$veiculos = $database->getReference('VC01')->getSnapshot();
	$proprietarios = $database->getReference('VC02')->getSnapshot();
	$avaliacoes = $database->getReference('VC05')->getSnapshot();
	$mecanicos = $database->getReference('VC20')->getSnapshot();
	$StatusMecanicos = $database->getReference('VC23')->getSnapshot();
	
	$i = 1;
	foreach($avaliacoes->getValue() as $avaliacao) :
		$id_aval_max = $i;
		$i ++;
	endforeach;
	
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <style type="text/css">
      .carregando{
        color:#ff0000;
        display:none;
      }
    </style>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>GetsCar</title>
  </head>
<body>
  
    <div class="container">
      <div class="row">
        <div class="col">
        <h1>Nova Avaliação</h1>
		<p>
        <strong>
          <?php 
            echo $msg;
          ?>
        <strong>
      </p>
        <nav class="navbar navbar-light bg-light">
          <form method="POST">
			<input class="form-control" type="hidden" name="id" id="id" placeholder="ID" value="<?php echo $id_aval_max ?>">
            <select name="VC05_CD_PROP" id="VC05_CD_PROP" class='form-control'>    
              <option value="" selected = selected>Selecione o proprietário</option>
              <?php 
			    foreach($proprietarios->getValue() as $proprietario) :
					echo "<option class='"."form-control"." '. value='".$proprietario["VC02_ID_PROP"]."'>".$proprietario["VC02_NM_PROP"]." - ".$proprietario["VC02_NR_CPFCNPJ"]."</option>";
				endforeach;
			  ?> 
            </select><br>
            
            <span class="carregando">Aguarde, carregando... </span>
            <select name="VC05_CD_CAR" id="VC05_CD_CAR" class='form-control'>    
              <option value="" required="required" selected = selected checked disabled>Selecione o veículo</option>
            </select><br>
			
			<select name="VC05_CD_FUNC" id="VC05_CD_FUNC" class='form-control'>    
              <option value="" required="required" selected = selected>Selecione o mecânico</option>
              	<?php 
					foreach($mecanicos->getValue() as $mecanico) :
						if($mecanico["VC20_ID_SETOR"] == 3){
							foreach($StatusMecanicos->getValue() as $StatusMecanico) :
								if($StatusMecanico["VC23_ID_FUNC"] == $mecanico["VC20_ID_FUNC"]){
									if($StatusMecanico["VC23_ID_STATUS"] == 1){
										echo "<option class='"."form-control"." '. value='".$mecanico["VC20_ID_FUNC"]."'>".$mecanico["VC20_ID_FUNC"]." - ".$mecanico["VC20_NM_FUNC"]."</option>";
									}
								}
							endforeach;
						}
					endforeach;
				?> 
            </select><br>
          <button class="btn btn-primary" type="submit">Cadastrar</button>
          <a href="index.php" class="btn btn-info">Menu</a>
		  </form>
        </nav>
        </div>
      </div>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://www.google.com/jsapi"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script type="text/javascript">
      $(function(){
        $('#VC05_CD_PROP').change(function(){
          if($(this).val()) {
            $('#VC05_CD_CAR').hide();
            $('.carregando').show();
			
            $.getJSON('veiculos.php?search=',{prop: $(this).val(), ajax: 'true'}, function(j){
              var options = '<option value=""> Escolha o veículo</option>';
              for(var i = 0; i < j.length; i++) {
                options += '<option value="' + j[i].VC01_CD_CAR + '">' + j[i].VC01_NM_CAR + '</option>';
              }
              $('#VC05_CD_CAR').html(options).show();
              $('.carregando').hide();
            });
          } else {
              $('#VC05_CD_CAR').html('<option value=""> - Escolha o funcionário - </option>');
          }
        });
      });
    </script>
  </body>
</html>
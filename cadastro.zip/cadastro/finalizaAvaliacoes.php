<?php
	require __DIR__.'/vendor/autoload.php';
    use Kreait\Firebase\Factory;
	include "conexao.php";
    $database = $factory->createDatabase();
	$idAval = $_GET['id'] ?? '';
	$idAvaliacao = $idAval;
	$idAvaliacao--;
	$veiculos = $database->getReference('VC01')->getSnapshot();
	$proprietarios = $database->getReference('VC02')->getSnapshot();
    $avaliacoes = $database->getReference('VC05')->getSnapshot();
	$statusAvaliacao = $database->getReference('VC06')->getSnapshot();
	$itensAval = $database->getReference('VC07')->getSnapshot();
	$statusMecanico = $database->getReference('VC23')->getSnapshot();
	
    $msg = "Avaliação finalizada com sucesso!";
	
	foreach($avaliacoes->getValue() as $avaliacao) :
		if($avaliacao['VC05_ID_AVAL'] == $idAval){
			
			$aval = [
				'VC05_CD_CAR' => $avaliacao['VC05_CD_CAR'],
				'VC05_CD_FUNC' => $avaliacao['VC05_CD_FUNC'],
				'VC05_CD_PROP' => $avaliacao['VC05_CD_PROP'],
				'VC05_ID_AVAL' => $idAval,
				'VC05_ID_STATUS' => 2
			];
			$database -> getReference('VC05/' . $idAvaliacao)->set($aval);
			
			$func = $avaliacao['VC05_CD_FUNC'];
			$idMecanico = $func;
			$idMecanico--;
			$atualizaStatusMecanico = [
				'VC23_ID_FUNC' => $func,
				'VC23_ID_STATUS' => 1,
				'VC23_DT_ATUSIS' => date('Ymd h:i:s') 
			];
			$database -> getReference('VC23/' . $idMecanico)->set($atualizaStatusMecanico);

			header("location: pesquisaAvaliacoes.php");
		}
	endforeach;
	
	$msg = "Erro ao finalizar avaliação! Tente novamente.";
	header("location: pesquisaAvaliacoes.php");
	
?>

<!doctype html>
<html lang="en">
  <head>
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js" type="text/javascript"></script>
    
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>    

    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>

  <title>Finalização de avaliação</title>
	<link href="css/cadastroCarro.css" rel="stylesheet">
  </head>
  <body>
	<p>
        <strong>
          <?php 
            echo $msg;
          ?>
        <strong>
    </p>
  <script>
    $('.date-own').datepicker({
    format: "yyyy",
    viewMode: "years", 
    minViewMode: "years"
    });
    $(document).ready(function() {
    $("#amount").on("input", function() {
        // allow numbers, a comma or a dot
        var v= $(this).val(), vc = v.replace(/[^0-9,\.]/, '');
        if (v !== vc)        
            $(this).val(vc);
    });
    $("#distance").on("input", function() {
        // allow numbers, a comma or a dot
        var v= $(this).val(), vc = v.replace(/[^0-9,\.]/, '');
        if (v !== vc)        
            $(this).val(vc);
    });
});

  </script>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>	
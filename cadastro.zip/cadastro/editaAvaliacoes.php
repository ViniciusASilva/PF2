<?php
	require __DIR__.'/vendor/autoload.php';
    use Kreait\Firebase\Factory;
	include "conexao.php";
    $database = $factory->createDatabase();
	$idAval = $_GET['id'] ?? '';
	$idAvaliacao = $idAval;
	$idAvaliacao--;
	
	$veiculos = $database->getReference('VC01')->getSnapshot();
	$proprietarios = $database->getReference('VC02')->getSnapshot();
    $avaliacoes = $database->getReference('VC05')->getSnapshot();
	$statusAvaliacao = $database->getReference('VC06')->getSnapshot();
	$itensAval = $database->getReference('VC07')->getSnapshot();
	$funcionarios = $database->getReference('VC20')->getSnapshot();
	
    $msg = '';
    if(isset($_POST['id'])) {

      $itemAval = [
        'VC07_ID_AVAL' => $idAval,
        'VC07_DS_LANC' => $_POST['VC07_DS_LANC'],
        'VC07_VL_TOTAL' => $_POST['VC07_VL_TOTAL']
      ];
      $database -> getReference('VC07/' . $idAvaliacao)->set($itemAval);
	  
	  
	  if(isset($_POST['VC05_ID_STATUS'])) {
		  $status = 2;
		  echo $status;
		  
		  $aval = [
			'VC05_CD_CAR' => $_POST['VC05_CD_CAR'],
			'VC05_CD_FUNC' => $_POST['VC05_CD_FUNC'],
			'VC05_CD_PROP' => $_POST['VC05_CD_PROP'],
			'VC05_ID_AVAL' => $idAval,
			'VC05_ID_STATUS' => $status
		  ];
	  }
	  
      $msg = "Avaliação alterado com sucesso!";
	  header("location: editaAvaliacoes.php?id=$idAval");
    }
	
	
	
?>

<!doctype html>
<html lang="en">
  <head>
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js" type="text/javascript"></script>
    
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>    

    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>

  <title>Alteração de veiculo</title>
	<link href="css/cadastroCarro.css" rel="stylesheet">
  </head>
  <body>
  
      <p>
        <strong>
          <?php 
            echo $msg;
          ?>
        <strong>
      </p>
  
  <?php 
	  foreach($avaliacoes->getValue() as $avaliacao):
		if($avaliacao['VC05_ID_AVAL'] == $idAval){
  ?>
  <div class="container">
    <div class="form-signin"> 
      <h2>Avaliação</h2>

      <form name="signup" method="post" class="form-signin">
		  <div class="row">
		  <!--ID-->
			<div class="form-group col-md-2">
				<input class="form-control" type="hidden" name="id" id="id" placeholder="ID" value="<?php echo $idAval ?>">
			</div>
		  </div>  
		  <div class="row">
			 <!--Proprietário-->
			<div class="form-group col-md-10">
			  <label for="name">Proprietário</label>
				<select name="VC05_CD_PROP" id="VC05_CD_PROP" class='form-control'>
				<?php 
					foreach($proprietarios->getValue() as $proprietario) :
						if($proprietario['VC02_ID_PROP'] == $avaliacao['VC05_CD_PROP']){
							echo "<option class='"."form-control"." '. value='".$proprietario["VC02_ID_PROP"]."'>".$proprietario["VC02_NM_PROP"]." - ".$proprietario["VC02_NR_CPFCNPJ"]."</option>";
						}
					endforeach;
				?> 
				</select> 
			</div>
			 <!--Veiculo-->
			<div class="form-group col-md-10">
			  <label for="name">Veiculo</label>
				<select name="VC05_CD_CAR" id="VC05_CD_CAR" class='form-control'>
					<?php 
						foreach($veiculos->getValue() as $veiculo) :
							if($veiculo['VC01_CD_CAR'] == $avaliacao['VC05_CD_CAR']){
								echo "<option class='"."form-control"." '. value='".$veiculo["VC01_CD_CAR"]."'>".$veiculo["VC01_NM_CAR"]."</option>";
							}
						endforeach;
					?> 
				</select> 
			</div>
			 <!--Mecanico-->
			<div class="form-group col-md-10">
			  <label for="name">Mecanico</label>
				<select name="VC05_CD_FUNC" id="VC05_CD_FUNC" class='form-control'>
					<?php 
						foreach($funcionarios->getValue() as $funcionario) :
							if($funcionario['VC20_ID_FUNC'] == $avaliacao['VC05_CD_FUNC']){
								echo "<option class='"."form-control"." '. value='".$funcionario["VC20_ID_FUNC"]."'>".$funcionario["VC20_NM_FUNC"]."</option>";
							}
						endforeach;
					?> 
				</select><br>
			</div>
			<!--Modelo-->
			<?php 
				foreach($itensAval->getValue() as $itemAval) :
					if($itemAval['VC07_ID_AVAL'] == $avaliacao['VC05_ID_AVAL']){
			?> 
			
			<div class="form-group col-md-10">
			    <label for="campo2">Descrição</label>
				<table class="table">
					<textarea class="form-control" name="VC07_DS_LANC" id="VC07_DS_LANC" rows="10">
						<?php echo $itemAval['VC07_DS_LANC'] ?>
					</textarea>
               </table>
			</div>
			
			<div class="form-group col-md-10">
			  <label for="campo2">Valor total</label>
			  <input class="form-control" type="text" name="VC07_VL_TOTAL" id="VC07_VL_TOTAL" placeholder="Valor Total" value="<?php echo $itemAval['VC07_VL_TOTAL'] ?>">
			</div>
			<?php
			    }
		      endforeach
		    ?>
			
			<!--status-->
			<div class="form-group col-md-10">
			  <label for="campo2">Encerrar Avaliação?</label>
			  <input class="form-check-input" type="checkbox" name="VC05_CD_STATUS" id="VC05_CD_STATUS" placeholder="Status" value="<?php echo $avaliacao['VC05_ID_STATUS'] ?>">
			</div>
		  </div>
      <!--ID-->
      <!-- <div class="form-group row">
          <div class="col-10">
            <input class="form-control" type="number" name="id" id="id" placeholder="ID">
          </div>
        </div> -->
          <div class="form-group col-md-10">
            <input type="submit" name="btnCadAutomovel" class="btn btn-primary" value="Cadastrar"\>
			<a href="encerraAval.php" class="btn btn-default">Encerrar</a>
            <a href="index.php" class="btn btn-default">Voltar</a>
		  </div>
      </form>
    </div>  
  </div>
  <?php
	}
  endforeach
  
  ?>
  <script>
    $('.date-own').datepicker({
    format: "yyyy",
    viewMode: "years", 
    minViewMode: "years"
    });
    $(document).ready(function() {
    $("#amount").on("input", function() {
        // allow numbers, a comma or a dot
        var v= $(this).val(), vc = v.replace(/[^0-9,\.]/, '');
        if (v !== vc)        
            $(this).val(vc);
    });
    $("#distance").on("input", function() {
        // allow numbers, a comma or a dot
        var v= $(this).val(), vc = v.replace(/[^0-9,\.]/, '');
        if (v !== vc)        
            $(this).val(vc);
    });
});

  </script>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>	
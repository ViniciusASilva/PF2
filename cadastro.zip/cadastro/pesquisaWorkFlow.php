<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>Pesquisar avaliações</title>
  </head>
  <body>
  
   <?php
     include "conexao.php";
     $database = $factory->createDatabase();
	 $veiculos = $database->getReference('VC01')->getSnapshot();
	 $proprietarios = $database->getReference('VC02')->getSnapshot();
	 $funcionarios = $database->getReference('VC20')->getSnapshot();
	 $workflows = $database->getReference('VC25')->getSnapshot();
	 $fluxos = $database->getReference('VC26')->getSnapshot();
	 $tarefas = $database->getReference('VC27')->getSnapshot();
   ?> 
  
  
    <div class="container">
	  <div class="row">
	    <div class="col">
		  <h1>WorkFlows</h1>
		
		  <table class="table table-hover">
		    <thead>
			  <tr>
			    <th scope="col">WorkFlow</th>
			    <th scope="col">Veiculo</th>
				<th scope="col">Proprietário</th>
				<th scope="col">Data</th>
			    <th scope="col">Tarefa</th>
				<th scope="col">Funcoes</th>
			  </tr>
		    </thead>
		    <tbody>
			  
			 
			<?php
			  foreach ($workflows->getValue() as $workflow) : 
				if($workflow['VC25_ID_STATUS'] == 1) {
					$cod_aval = $workflow['VC25_NR_WORK'];
			?>
			<tr>
					<?php 
						$idFluxo = 2;
						foreach($fluxos->getValue() as $fluxo) :
							if($fluxo['VC26_NR_FLUXO'] == $workflow['VC25_CD_FLUXO']) {
								$idFluxo = 1;
								echo "<td>'".$workflow['VC25_NR_WORK']." - ".$fluxo['VC26_DS_FLUXO']."'</td>";
							}
						endforeach;
						if ($idFluxo == 2){
							echo "<td> </td>";
						}
		
					?>
				<?php
				    $idCar = 2;
					foreach($veiculos->getValue() as $veiculo) :
						if($veiculo['VC01_CD_CAR'] == $workflow['VC25_CD_CAR']) {
							$idCar = 1;
							echo "<td>'".$veiculo['VC01_NM_CAR']."'</td>";
						}
					endforeach;
					if ($idCar == 2){
						echo "<td> </td>";
					}
				?>
				<?php
				    $idProp = 2;
					foreach($proprietarios->getValue() as $proprietario) :
						if($proprietario['VC02_ID_PROP'] == $workflow['VC25_CD_PROP']) {
							$idProp = 1;
							echo "<td>'".$proprietario['VC02_NM_PROP']."'</td>";
						}
					endforeach;
					if ($idProp == 2){
						echo "<td> </td>";
					}
				?>
				<?php
					if(!EMPTY($workflow['VC25_DT_WORK'])) {
						$idFunc = 1;
						echo "<td>'".$workflow['VC25_DT_WORK']."'</td>";
					}
					else {
						echo "<td> </td>";
					}
				?>
				<?php
				    $idTar = 2;
					foreach($tarefas->getValue() as $tarefa) :
						if ($tarefa['VC27_NR_FLUXO'] == $workflow['VC25_CD_FLUXO']) {
							if($tarefa['VC27_NR_TAREFA'] == $workflow['VC25_NR_TAREFA']) {
								$idTar = 1;
								echo "<td>'".$tarefa['VC27_DS_TAREFA']."'</td>";
							}
						}
					endforeach;
					if ($idTar == 2){
						echo "<td> </td>";
					}
				?>
				<?php
				  echo "<td width=150px> 
				          <a href='editaWork.php?id=$cod_aval' class='btn btn-primary'>Selecionar</a> 
						  <a href='finalizaAvaliacoes.php?id=$cod_aval' class='btn btn-danger'>Finalizar</a> 
						</td>"
				?>
			</tr>
				   
				  
			<?php
				}
				endforeach;
			?>  
			  
		    </tbody>
		  </table>
		
		  <a href="index.php" class="btn btn-info">Voltar para o inicio</a>
	    </div>
	  </div>
    </div>
	
	<!-- Modal -->
	<div class="modal fade" id="confirma" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog" role="document">
		<div class="modal-content">
		  <div class="modal-header">
			<h5 class="modal-title" id="exampleModalLabel">Confirmação de exclusão</h5>
			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			  <span aria-hidden="true">&times;</span>
			</button>
		  </div>
		  <div class="modal-body">
		  <form action="excluindo.php" method="POST">
			<p>Deseja realmente excluir <b id="nome_carro"> Nome do carro</b> ?</p>
		  </div>
		  <div class="modal-footer">
			  <button type="button" class="btn btn-secondary" data-dismiss="modal">Não</button>
			  <input type="hidden" name="nome" id="nome_carro_1" value="">
			  <input type="hidden" name="id" id="cod_carro" value="">
			  <input type="submit" class="btn btn-danger" value="Excluir">
			</form>
		  </div>
		</div>
	  </div>
	</div>
	
	<script type="text/javascript">
	  function pegar_dados(id, nome) {
		  document.getElementById('nome_carro').innerHTML = nome;
		  document.getElementById('nome_carro_1').value = nome;
		  document.getElementById('cod_carro').value = id;
		  window.alert(nome);
	  }
	</script>
	
	
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>
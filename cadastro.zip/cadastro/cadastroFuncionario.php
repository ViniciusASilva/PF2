<?php
    require __DIR__.'/vendor/autoload.php';
    use Kreait\Firebase\Factory;
	$factory =  (new Factory()) -> withDatabaseUri('https://projeto-final-e1184.firebaseio.com/');
	$database = $factory->createDatabase();
    $msg = '';
    if(isset($_POST['id'])) {
      $novoCarro = [
        'id' => $_POST['id'],
        'proprietario' => $_POST['proprietario'],
        'modelo' => $_POST['modelo'],
        'marca' => $_POST['marca'],
        'ano' => $_POST['ano'],
        'cor' => $_POST['cor'],
        'placa' => $_POST['placa'],
        'passageiros' => $_POST['passageiros'],
        'amount' => $_POST['valorCompra'],
        'distance' => $_POST['kmRodado']
      ];
      $database -> getReference('cadastroCarro/' . $_POST['id'])->set($novoCarro);
      $msg = "Carro cadastrado com sucesso!";
    }
    
	$funcionarios = $database->getReference('VC20')->getSnapshot();
	
	foreach($funcionarios->getValue() as $funcionario) :
	    $i = 1;
		if ($funcionario['VC20_ID_FUNC'] == $i) {
			$id_mec_max = $funcionario['VC20_ID_FUNC'];
		}
		$i ++;
	endforeach;
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js" type="text/javascript"></script>
    
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>    

    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>


    <title>Cadastro de Proprietário</title>
    <link href="css/cadastroCarro.css" rel="stylesheet">
  </head>
  <body>
  <div class="container">
    <div class="form-signin"> 
      <h2>Cadastrar Proprietário</h2>
      <p>
        <strong>
          <?php 
            echo $msg;
          ?>
        <strong>
      </p>
      <form name="signup" method="post" class="form-signin">
      <!--ID-->
      <div class="form-group row">
          <div class="col-10">
            <input class="form-control" type="hid" name="id" id="id" placeholder="ID" value="<?php echo $id_mec_max ?>">
          </div>
        </div>
          <!--Proprietário-->
          <div class="form-group row">
            <div class="col-10">
              <input class="form-control" type="text" name="proprietario" id="proprietario" placeholder="Nome do proprietário">
            </div>
          </div>
          <!--Modelo-->
          <div class="form-group row">
            <div class="col-10">
              <input class="form-control" type="text" name="modelo" id="modelo" placeholder="Modelo">
            </div>
          </div>
          <!--Marca-->
          <div class="form-group row">
            <div class="col-10">
              <input class="form-control" type="text" name="marca" id="marca" placeholder="Marca">
            </div>
          </div>
          <!--Ano-->
          <div class="form-group row">
            <div class="col-10">
              <input class="date-own form-control" type="text" name="ano" id="ano" placeholder="Ano">
            </div>
          </div>
          <!--Cor-->
          <div class="form-group row">
            <div class="col-10">
              <input class="form-control" type="color" value="#563d7c" name="cor" id="cor" id="example-color-input">
            </div>
          </div>
           <!--Placa-->
           <div class="form-group row">
            <div class="col-10">
              <input class="form-control" type="text" name="placa" id="placa" placeholder="Placa">
            </div>
          </div>
           <!--Passageiros-->
           <div class="form-group row">
            <div class="col-10">
              <input class="form-control" type="text" name="passageiros" id="passageiros" placeholder="Passageiros">
            </div>
          </div>
           <!--Valor da Compra-->
           <div class="form-group row">
            <div class="col-10">
              <input class="form-control" type="text" name="valorCompra" id="valorCompra"  placeholder="Valor da Compra">
            </div>
          </div>
           <!--Kilometros Rodados-->
           <div class="form-group row">
            <div class="col-10">
              <input class="form-control" type="text" name="kmRodado" id="kmRodado"  placeholder="Kilometros Rodados">
            </div>
          </div>
          
          <input type="submit" name="btnCadAutomovel" class="btn btn-success mr-5" value="Cadastrar"\>
          <a href="index.php" class="btn btn-success ml-5">Voltar</a>
      </form>
    </div>  
	</div>

  <script>
    $('.date-own').datepicker({
    format: "yyyy",
    viewMode: "years", 
    minViewMode: "years"
    });
    $(document).ready(function() {
    $("#valorCompra").on("input", function() {
        // allow numbers, a comma or a dot
        var v= $(this).val(), vc = v.replace(/[^0-9,\.]/, '');
        if (v !== vc)        
            $(this).val(vc);
    });
    $("#kmRodado").on("input", function() {
        // allow numbers, a comma or a dot
        var v= $(this).val(), vc = v.replace(/[^0-9,\.]/, '');
        if (v !== vc)        
            $(this).val(vc);
    });
});

  </script>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>	
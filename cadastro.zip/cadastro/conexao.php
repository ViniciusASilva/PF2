<?php
  require __DIR__.'/vendor/autoload.php';
  use Kreait\Firebase\Factory;
  $factory =  (new Factory()) ->withDatabaseUri('https://projeto-final-e1184.firebaseio.com/');
  $auth = $factory->createAuth();
?>



<!DOCTYPE html>
<html lang="en">
    <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    
    <title>Promoções</title>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th scope="col">Id</th>
                            <th scope="col">Modelo</th>
                            <th scope="col">Marca</th>
                            <th scope="col">KM</th>
                            <th scope="col">ANO</th>
                            <!-- <th scope="col">Vaga</th> -->
                            <th scope="col">Placa</th>
                            <th scope="col">Valor</th>
                            <th scope="col">Selecionar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            include('promoConexao.php');
                            $ref = "VC01/";
                            $fetchdata = $database->getReference($ref)->getValue();
                            foreach($fetchdata as $key => $row)
                            {                                 
                            ?>
                                <tr>
                                    <td><?php echo $row['VC01_CD_CAR']; ?></td>
                                    <td><?php echo $row['VC01_NM_MODELO']; ?></td>
                                    <td><?php echo $row['VC01_CD_MARCA']; ?></td>
                                    <td><?php echo $row['VC01_NR_KM']; ?></td>
                                    <td><?php echo $row['VC01_DT_ANO']; ?></td>
                                    <!-- <td><?php echo $row[''] ;?></td> -->
                                    <td><?php echo $row['VC01_DS_PLACA']; ?></td>
                                    <td><?php echo $row['VC01_VL_VENDA']; ?></td>
                                    <td>
                                        <a href="index.php" class="btn btn-primary">Selecionar</a>
                                    </td>
                                </tr>
                            <?php
                            }
                            ?>
                    </tbody>
                </table> 
            </div>
        </div>
    </body>
</html>

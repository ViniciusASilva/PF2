<?php
	require __DIR__.'/vendor/autoload.php';
    use Kreait\Firebase\Factory;
	include "conexao.php";
    $database = $factory->createDatabase();
	$work = $_GET['id'] ?? '';
	$workflow = $work;
	$workflow--;
	
	$veiculos = $database->getReference('VC01')->getSnapshot();
	$proprietarios = $database->getReference('VC02')->getSnapshot();
    $avaliacoes = $database->getReference('VC05')->getSnapshot();
	$statusAvaliacao = $database->getReference('VC06')->getSnapshot();
	$itensAval = $database->getReference('VC07')->getSnapshot();
	$workflows = $database->getReference('VC25')->getSnapshot();
	$fluxos = $database->getReference('VC26')->getSnapshot();
	$tarefas = $database->getReference('VC27')->getSnapshot();
	
    $msg = '';
    if(isset($_POST['id'])) {
	  if(!EMPTY($_POST['VC25_CD_CAR'])) {
		  $neWork = [
			'VC25_CD_CAR' => $_POST['VC25_CD_CAR'],
			'VC25_CD_FLUXO' => $_POST['VC25_CD_FLUXO'],
			'VC25_CD_PROP' => $_POST['VC25_CD_PROP'],
			'VC25_DT_WORK' => $_POST['VC25_DT_WORK'],
			'VC25_ID_STATUS' => 1,
			'VC25_NR_TAREFA' => $_POST['VC25_NR_TAREFA'],
			'VC25_NR_WORK' => $work
		  ];
		  $database -> getReference('VC25/' . $workflow)->set($neWork);
		  
		  $msg = "Avaliação alterado com sucesso!";
		  header("location: editaWork.php?id=$work");
	  }
	  
    }
	
	
	
?>

<!doctype html>
<html lang="en">
  <head>
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js" type="text/javascript"></script>
    
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>    

    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>

  <title>Alteração de veiculo</title>
	<link href="css/cadastroCarro.css" rel="stylesheet">
  </head>
  <body>
  
      <p>
        <strong>
          <?php 
            echo $msg;
          ?>
        <strong>
      </p>
  
  <?php 
	  foreach($workflows->getValue() as $workflow):
		if($workflow['VC25_NR_WORK'] == $work){
  ?>
  <div class="container">
    <div class="form-signin"> 
      <h2>WorkFlow</h2>

      <form name="signup" method="post" class="form-signin">
		  <div class="row">
		  <!--ID-->
			<div class="form-group col-md-2">
				<input class="form-control" type="hidden" name="id" id="id" placeholder="ID" value="<?php echo $work ?>">
			</div>
		  </div>  
		  <div class="row">
			<div class="form-group col-md-10">
				<label for="name">Fluxo</label>
				<?php

					foreach($fluxos->getValue() as $fluxo) :
							if($fluxo['VC26_NR_FLUXO'] == $workflow['VC25_CD_FLUXO']){
								echo "<input class='"."form-control"." '. value='".$fluxo["VC26_DS_FLUXO"]."'>";
							}
					endforeach;

				?>
			</div>
			<div class="form-group col-md-10">
				<?php

					foreach($fluxos->getValue() as $fluxo) :
							if($fluxo['VC26_NR_FLUXO'] == $workflow['VC25_CD_FLUXO']){
								$cdFluxo = $fluxo["VC26_NR_FLUXO"];
							}
					endforeach;

				?>
				<input type="hidden" id="VC25_CD_FLUXO" name="VC25_CD_FLUXO" value="<?php echo $cdFluxo ?>">
			</div>
		  </div>  
		  <div class="row">
			 <!--Proprietário-->
			<div class="form-group col-md-10">
			  <label for="name">Proprietário</label>
				<select name="VC25_CD_PROP" id="VC25_CD_PROP" class='form-control'>
				<?php 
					foreach($proprietarios->getValue() as $proprietario) :
						if($proprietario['VC02_ID_PROP'] == $workflow['VC25_CD_PROP']){
							echo "<option class='"."form-control"." '. value='".$proprietario["VC02_ID_PROP"]."'>".$proprietario["VC02_NM_PROP"]." - ".$proprietario["VC02_NR_CPFCNPJ"]."</option>";
						}
					endforeach;
				?> 
				</select> 
			</div>
			 <!--Veiculo-->
			<div class="form-group col-md-10">
			  <label for="name">Veiculo</label>
				<select name="VC25_CD_CAR" id="VC25_CD_CAR" class='form-control'>
					<?php 
						foreach($veiculos->getValue() as $veiculo) :
							if($veiculo['VC01_CD_CAR'] == $workflow['VC25_CD_CAR']){
								echo "<option class='"."form-control"." '. value='".$veiculo["VC01_CD_CAR"]."'>".$veiculo["VC01_NM_CAR"]."</option>";
							}
						endforeach;
					?> 
				</select> 
			</div>
			 <!--Mecanico-->
			<div class="form-group col-md-10">
			  <label for="name">Tarefa</label>
				<select name="VC25_NR_TAREFA" id="VC25_NR_TAREFA" class='form-control'>
					<?php 
						foreach($tarefas->getValue() as $tarefa) :
							if($tarefa['VC27_NR_FLUXO'] == $workflow['VC25_CD_FLUXO']){
								if($tarefa['VC27_NR_TAREFA'] == $workflow['VC25_NR_TAREFA']){
									echo "<option class='"."form-control"." '. value='".$tarefa["VC27_NR_TAREFA"]."'>".$tarefa["VC27_DS_TAREFA"]."</option>";
								}
							}
						endforeach;
					?> 
				</select><br>
			</div>
			<div class="form-group col-md-10">
			  <label for="name">Data abertura</label>
			  <input class="form-control" type="text" name="VC25_DT_WORK" id="VC25_DT_WORK" value="<?php echo $workflow['VC25_DT_WORK'] ?>">
			</div>
		  </div>
      <!--ID-->
      <!-- <div class="form-group row">
          <div class="col-10">
            <input class="form-control" type="number" name="id" id="id" placeholder="ID">
          </div>
        </div> -->
          <div class="form-group col-md-10">
            <input type="submit" name="btnCadAutomovel" class="btn btn-primary" value="Salvar"\>
			<a href="encerraAval.php" class="btn btn-default">Encerrar</a>
            <a href="index.php" class="btn btn-default">Voltar</a>
		  </div>
      </form>
    </div>  
  </div>
  <?php
	}
  endforeach
  
  ?>
  <script>
    $('.date-own').datepicker({
    format: "yyyy",
    viewMode: "years", 
    minViewMode: "years"
    });
    $(document).ready(function() {
    $("#amount").on("input", function() {
        // allow numbers, a comma or a dot
        var v= $(this).val(), vc = v.replace(/[^0-9,\.]/, '');
        if (v !== vc)        
            $(this).val(vc);
    });
    $("#distance").on("input", function() {
        // allow numbers, a comma or a dot
        var v= $(this).val(), vc = v.replace(/[^0-9,\.]/, '');
        if (v !== vc)        
            $(this).val(vc);
    });
});

  </script>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>	
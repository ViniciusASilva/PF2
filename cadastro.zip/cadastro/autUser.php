<?php

include("conexao.php");

if(isset($_POST['btnCadUsuario'])){
    
    $email = $_POST['VC09_DS_EMAIL'];
    $senha = $_POST['VC09_NR_SENHA'];
    
    $user = $auth->createUserWithEmailAndPassword($email, $senha);
    header("Location:index.php");
}
?>
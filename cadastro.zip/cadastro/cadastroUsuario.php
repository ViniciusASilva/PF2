<?php
    require __DIR__.'/vendor/autoload.php';
    
    use Kreait\Firebase\Factory;
    
    include "conexao.php";
    
    $database = $factory->createDatabase();
    
    $msg = '';
    
    if(isset($_POST['id'])) {
      $novoUser = [
        'VC09_DS_EMAIL' => $_POST['VC09_DS_EMAIL'],
        'VC09_ID_USER' => $_POST['id'],
		'VC09_ID_SEXO' => $_POST['VC09_ID_SEXO'],
        'VC09_NM_USER' => $_POST['VC09_NM_USER'],
		'VC09_NR_CPF' => $_POST['VC09_NR_CPF'],
		'VC09_NR_SENHA' => $_POST['VC09_NR_SENHA'],
		'VC09_NR_IDADE' => $_POST['VC09_NR_IDADE']
      ];
      $database -> getReference('VC09/' . $_POST['id'])->set($novoUser);
      $msg = "Usuario cadastrado com sucesso!";
    }
	
	$usuario = $database->getReference('VC09')->getSnapshot();
    
    foreach($usuario->getValue() as $usuario) :
	    $i = 1;
			$id_prop_max = 1;
		$i ++;
	endforeach;
?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js" type="text/javascript"></script>
    
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>    

    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>


    <title>Cadastro de Usuario</title>
    <link href="css/cadastroCarro.css" rel="stylesheet">
  </head>
  <body>
  <div class="container">
    <div class="form-signin"> 
      <h2>Cadastrar Usuario</h2>
      <p>
        <strong>
          <?php 
            echo $msg;
          ?>
        <strong>
      </p>
      <form name="signup" method="post" class="form-signin">
        <div class="row">
      <!--ID-->
        <div class="form-group col-md-2">
            <label for="name">ID</label>
            <input class="form-control" type="number" name="id" id="id" placeholder="ID" value="<?php echo $id_prop_max ?>">
        </div>
      </div>
      <!--CPF-->
      <div class="row">
	    <div class="form-group col-md-3">
        <label for="name">CPF</label>
          <input class="form-control" type="number" name="VC09_NR_CPF" id="VC09_NR_CPF" placeholder="CPF">
        </div>
         <!--Usuario-->
        <div class="form-group col-md-5">
          <label for="name">Nome do usuario</label>
          <input class="form-control" type="text" name="VC09_NM_USER" id="VC09_NM_USER" placeholder="Nome do usuario">
        </div>
        <!--Idade-->
		<div class="form-group col-md-5">
          <label for="name">Idade</label>
          <input class="form-control" type="number" name="VC09_NR_IDADE" id="VC09_NR_IDADE" placeholder="Idade">
        </div>
        <!--Sexo-->
		<div class="form-group col-md-5">
          <label for="name">Sexo</label>
          <input class="form-control" type="text" name="VC09_ID_SEXO" id="VC09_ID_SEXO" placeholder="Sexo">
        </div>
        <!--Email-->
		<div class="form-group col-md-5">
          <label for="name">E-mail</label>
          <input class="form-control" type="email" name="VC09_DS_EMAIL" id="VC09_DS_EMAIL" placeholder="E-mail">
        </div>
        <!--Senha-->
		<div class="form-group col-md-5">
          <label for="name">Senha</label>
          <input class="form-control" type="password" name="VC09_NR_SENHA" id="VC09_NR_SENHA" placeholder="Senha" >
        </div>
      </div>
		  <button type="submit" name="btnCadUsuario" class="btn btn-primary" target="_blank" action="autUser.php">Cadastrar</button>
          <a href="index.php" class="btn btn-default">Voltar</a>
      </form>
    </div>  
	</div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>	
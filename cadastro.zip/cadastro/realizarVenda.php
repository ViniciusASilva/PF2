
<?php
    require __DIR__.'/vendor/autoload.php';
    use Kreait\Firebase\Factory;
	include "conexao.php";
    $database = $factory->createDatabase();
    $msg = '';
    if(isset($_POST['id'])) {
      $novaVenda = [
        'VC10_NR_VENDA' => $_POST['id'],
        'VC10_CD_CAR' => $_POST['VC10_CD_CAR'],
        'VC10_CD_VENDED' => $_POST['VC10_CD_VENDED'],
        'VC10_CD_FORPAG' => $_POST['VC10_CD_FORPAG'],
		'VC10_VL_VENDA' => $_POST['VC10_VL_VENDA'],
		'VC10_VL_DESC' => $_POST['VC10_VL_DESC']
      ];
      $database -> getReference('VC10/' . $_POST['id'])->set($novaVenda);

      $msg = "Venda realizada com sucesso!";
      // header("location: index.php");
    }
	
	if(isset($_POST['id'])) {
		
	  $estoques = $database->getReference('VC12')->getSnapshot();
	  $no = 0;
	  foreach($estoques->getValue() as $estoque):
		if($estoque['VC12_CD_CAR'] == $_POST['VC10_CD_CAR']){
			$idEstoque = $no;
		}
		$no++;
	  endforeach;
		
      $atualizaEstoque = [
        'VC12_CD_CAR' => $_POST['VC10_CD_CAR'],
        'VC12_ID_STATUS' => 2,
        'VC12_QT_ESTOQ' => 0,
		'VC12_DT_ESTOQ' =>  date('Ymd') 
      ];
      $database -> getReference('VC12/' . $idEstoque)->set($atualizaEstoque);
	  
      $msg = "Estoque atualizado com sucesso!";
    }
	
	$veiculos = $database->getReference('VC01')->getSnapshot();
	$vendas = $database->getReference('VC10')->getSnapshot();
	$estoques = $database->getReference('VC12')->getSnapshot();
	$formasPag = $database->getReference('VC11')->getSnapshot();
	$vendedores = $database->getReference('VC20')->getSnapshot();
	
	$i = 0;
	foreach($vendas->getValue() as $venda) :
		$id_venda_max = $i;	
		$i ++;
	endforeach;
	
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>Vendas</title>
  </head>
  <body>
	<div class="container">
    <div class="form-signin"> 
      <h2>Nova Venda</h2>
      <p>
        <strong>
          <?php 
            echo $msg;
          ?>
        <strong>
      </p>
      <form name="signup" method="post" class="form-signin">
      <div class="row">
      <!--ID-->
        <div class="form-group col-md-2">
            <input class="form-control" type="hidden" name="id" id="id" placeholder="ID" value="<?php echo $i ?>">
        </div>
      </div>  
      <div class="row">
         <!--Proprietário-->
        <div class="form-group col-md-10">
			<label for="name">Vendedor</label>
			<select name="VC10_CD_VENDED" id="VC10_CD_VENDED" class='form-control'>
			<option value=""> </option>
			<?php 
			    foreach($vendedores->getValue() as $vendedor) :
				if($vendedor["VC20_ID_SETOR"] == 1){
					if($vendedor["VC20_ID_STATUS"] == 1){
						echo "<option class='"."form-control"." '. value='".$vendedor["VC20_ID_FUNC"]."'>".$vendedor["VC20_ID_FUNC"]." - ".$vendedor["VC20_NM_FUNC"]."</option>";
					}
				}
				endforeach;
			?> 
			</select> 
        </div>
        <!--Modelo-->
        <div class="form-group col-md-5">
          <label for="campo2">Veículo</label>
          <select name="VC10_CD_CAR" id="VC10_CD_CAR" class='form-control'>
		  <option value=""> </option>
			<?php 
				foreach($veiculos->getValue() as $veiculo) :
				    foreach($estoques->getValue() as $estoq): 
						if($estoq['VC12_CD_CAR'] == $veiculo['VC01_CD_CAR']){
							if($estoq['VC12_ID_STATUS'] == 1){
								echo "<option class='"."form-control"." '. value='".$veiculo["VC01_CD_CAR"]."'>".$veiculo["VC01_NM_CAR"]."</option>";
							}
						}
					endforeach;
				endforeach;
			?> 
			</select> 
        </div>
      </div>
	  <div class="row">
		  <div class="form-group col-md-5">
			 <label for="campo2">Valor venda</label>
			 <input class="form-control" type="number" name="VC10_VL_VENDA" id="VC10_VL_VENDA" placeholder="Valor de venda" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==7) return false;">
		  </div>
		  <div class="form-group col-md-5">
			 <label for="campo2">Valor desconto</label>
			 <input class="form-control" type="number" name="VC10_VL_DESC" id="VC10_VL_DESC" placeholder="Valor de desconto" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==5) return false;">
		  </div>
	  </div>
	  	  <div class="row">
		  <div class="form-group col-md-5">
			<label for="campo2">forma de pagamento</label>
			<select name="VC10_CD_FORPAG" id="VC10_CD_FORPAG" class='form-control'>
				<option value=""> </option>
				<?php 
					foreach($formasPag->getValue() as $formaPag) :
						echo "<option class='"."form-control"." '. value='".$formaPag["VC11_ID_PAG"]."'>".$formaPag["VC11_DS_PAG"]."</option>";
					endforeach;
				?> 
			</select>
		  </div>
	  </div>
      <div class="form-group">
        <button type="submit" name="btnCadAval" class="btn btn-primary">Cadastrar</button>
        <a href="index.php" class="btn btn-info">Menu</a>
      </div>
      </form>
    </div>  
	</div>

  <script>
    
    $('.date-own').datepicker({
    format: "yyyy",
    viewMode: "years", 
    minViewMode: "years"
    });

    $(document).ready(function() {
		$("#valorCompra").on("input", function() {
			// allow numbers, a comma or a dot
			var v= $(this).val(), vc = v.replace(/[^0-9,\.]/, '');
			if (v !== vc)        
				$(this).val(vc);
		});
		
		$("#kmRodado").on("input", function() {
			// allow numbers, a comma or a dot
			var v= $(this).val(), vc = v.replace(/[^0-9,\.]/, '');
			if (v !== vc)        
				$(this).val(vc);
		});
	});

  </script>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>

<?php
    require __DIR__.'/vendor/autoload.php';
    use Kreait\Firebase\Factory;
	include "conexao.php";
    $database = $factory->createDatabase();
    $msg = '';
    if(isset($_POST['id'])) {
	  if(!EMPTY($_POST['VC25_CD_FLUXO']) && !EMPTY($_POST['VC25_CD_CAR']) && !EMPTY($_POST['VC25_CD_PROP'])) {
		  $idWork = $_POST['id'];
		  $idWork++;
		  $novoWork = [
			'VC25_NR_WORK' => $idWork,
			'VC25_CD_FLUXO' => $_POST['VC25_CD_FLUXO'],
			'VC25_CD_CAR' => $_POST['VC25_CD_CAR'],
			'VC25_CD_PROP' => $_POST['VC25_CD_PROP'],
			'VC25_DT_WORK' => date('Ymd'),
			'VC25_ID_STATUS' => 1
		  ];
		  $database -> getReference('VC25/' . $_POST['id'])->set($novoWork);
		  $msg = "WorkFlow cadastrado com sucesso!";
		  
	  }
	  else
	    $msg = "Erro ao cadastrar workFlow. Selecione todos os itens!";
    }
	
	$veiculos = $database->getReference('VC01')->getSnapshot();
	$proprietarios = $database->getReference('VC02')->getSnapshot();
	$avaliacoes = $database->getReference('VC05')->getSnapshot();
	$workflows = $database->getReference('VC26')->getSnapshot();
	$fluxos = $database->getReference('VC26')->getSnapshot();
	
	$i = 0;
	foreach($workflows->getValue() as $workflow) :
		$i ++;
		$idWork = $i;
	endforeach;
	
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <style type="text/css">
      .carregando{
        color:#ff0000;
        display:none;
      }
    </style>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>GetsCar</title>
  </head>
<body>
  
    <div class="container">
      <div class="row">
        <div class="col">
        <h1>Novo WorkFlow</h1>
		<p>
        <strong>
          <?php 
            echo $msg;
          ?>
        <strong>
      </p>
        <nav class="navbar navbar-light bg-light">
          <form method="POST">
			<input class="form-control" type="hidden" name="id" id="id" placeholder="ID" value="<?php echo $idWork ?>">
            <select name="VC25_CD_PROP" id="VC25_CD_PROP" class='form-control'>    
              <option value="" selected = selected>Selecione o proprietário</option>
              <?php 
			    foreach($proprietarios->getValue() as $proprietario) :
					echo "<option class='"."form-control"." '. value='".$proprietario["VC02_ID_PROP"]."'>".$proprietario["VC02_NM_PROP"]." - ".$proprietario["VC02_NR_CPFCNPJ"]."</option>";
				endforeach;
			  ?> 
            </select><br>
            
            <span class="carregando">Aguarde, carregando... </span>
            <select name="VC25_CD_CAR" id="VC25_CD_CAR" class='form-control'>    
              <option value="" required="required" selected = selected checked disabled>Selecione o veículo</option>
            </select><br>
			
			<select name="VC25_CD_FLUXO" id="VC25_CD_FLUXO" class='form-control'>    
              <option value="" required="required" selected = selected>Selecione o fluxo</option>
              	<?php 
					foreach($fluxos->getValue() as $fluxo) :
						echo "<option class='"."form-control"." '. value='".$fluxo["VC26_NR_FLUXO"]."'>".$fluxo["VC26_NR_FLUXO"]." - ".$fluxo["VC26_DS_FLUXO"]."</option>";
					endforeach;
				?> 
            </select><br>
          <button class="btn btn-primary" type="submit">Cadastrar</button>
          <a href="index.php" class="btn btn-info">Voltar para o inicio</a>
		  </form>
        </nav>
        </div>
      </div>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://www.google.com/jsapi"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script type="text/javascript">
      $(function(){
        $('#VC25_CD_PROP').change(function(){
          if($(this).val()) {
            $('#VC25_CD_CAR').hide();
            $('.carregando').show();
			
            $.getJSON('veiculos.php?search=',{prop: $(this).val(), ajax: 'true'}, function(j){
              var options = '<option value=""> Escolha o veículo</option>';
              for(var i = 0; i < j.length; i++) {
                options += '<option value="' + j[i].VC01_CD_CAR + '">' + j[i].VC01_NM_CAR + '</option>';
              }
              $('#VC25_CD_CAR').html(options).show();
              $('.carregando').hide();
            });
          } else {
              $('#VC25_CD_CAR').html('<option value=""> - Escolha o funcionário - </option>');
          }
        });
      });
    </script>
  </body>
</html>